import java.util.*;
class HashSetExample{
public static void main(String[] args){
HashSet<String> list=new HashSet<String>();
list.add("January");
list.add("Fabruary");
list.add("March");
list.add("April");
list.add("May");
list.add("June");
list.add("July");
list.add("August");
list.add("September");
list.add("October");
list.add("November");
list.add("December");
System.out.println(list);
System.out.println();
ListIterator l=list.listIterator();
System.out.println(list);
System.out.println();
System.out.println(l.next());
System.out.println(l.next());
System.out.println(l.next());
System.out.println(l.next());
System.out.println(l.next());
System.out.println(l.next());

while(l.hasPrevious()){
System.out.println(l.previous());
}
}
}