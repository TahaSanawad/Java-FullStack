import java.util.TreeSet;
import java.util.Iterator;



public class SetAssignment3 {

	public static void main(String[] args) 
	{
	TreeSet<String> set = new TreeSet<>();
	set.add("yash");
		set.add("yasha");
		set.add("yashaa");
		set.add("aashaay");
		Iterator<String> it = set.iterator();
		String query ="yasha";
		boolean result=false;
		while(it.hasNext()){
		if(it.next().equals(query)){
		result=true;
		break;
		}
		}
		if(result){
		System.out.println(query + " exist");}
		else{
		System.out.println(query + " do not exist");}
	}
	}