import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;
import java.util.Set;
import java.util.Map.Entry;
public class MapAssignment1{
	public static void main(String[] args){
	Map<String,String> map=new HashMap<>();
	map.put("student","yash");
	map.put("company","yash Technologies");
	map.put("location","Indore");
	
	Set<Entry<String,String>> set=map.entrySet();
	Iterator<Entry<String,String>> it = set.iterator();
	
	while (it.hasNext()){
	Map.Entry<String,String> me=it.next();
	if(me.getKey().equals("company")){
	System.out.println("key company exist");
	}
	}
	set =map.entrySet();
	it=set.iterator();
	while (it.hasNext()){
	Map.Entry<String,String> me=it.next();
	if(me.getValue().equals("yash")){
	System.out.println("vallue yash exist");
	}}
	set =map.entrySet();
	it=set.iterator();
	while (it.hasNext()){
	Map.Entry<String,String> me=it.next();
	System.out.println(me);
	}
	}
	
}