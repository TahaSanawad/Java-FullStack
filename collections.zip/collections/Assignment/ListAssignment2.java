import java.util.*;
class ListAssignment2
{	public static void main(String[] args)
	{
	ArrayList<Double> list=new ArrayList<Double>();
	Scanner sc = new Scanner(System.in);
	System.out.println("enter the number of elements");
	int n=sc.nextInt();
	
	for(int i=0;i<n;i++){
	try{
		double str=sc.nextDouble();
		list.add(str);
	}
	catch(InputMismatchException e){
		System.out.println("enter proper data type");
	}
	finally{
		sc.close();
	}
	}
	System.out.println(list);
	}
}