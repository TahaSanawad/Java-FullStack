import java.util.HashSet;
import java.util.Iterator;


public class SetAssignment2 {

	public static void main(String[] args) {
		HashSet<String> set = new HashSet<>();
		
		set.add("yash");
		set.add("yasha");
		set.add("yashaa");
		set.add("aashaay");
		
		Iterator<String> it = set.iterator();
		while (it.hasNext())
			System.out.println(it.next());

	}

}