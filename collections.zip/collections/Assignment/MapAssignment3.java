import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;
import java.util.Set;
import java.util.Map.Entry;
public class MapAssignment3{
	public static void main(String[] args){
	Map<String,Integer> map=new HashMap<>();
	map.put("yash",101);
	map.put("yasha",102);
	map.put("yashaa",103);
	
	Set<Entry<String,Integer>> set=map.entrySet();
	Iterator<Entry<String,Integer>> it = set.iterator();
	
	while (it.hasNext()){
	Map.Entry<String,Integer> me=it.next();
	if(me.getKey().equals("yash")){
	System.out.println("key yash exist");
	}
	}
	set =map.entrySet();
	it=set.iterator();
	while (it.hasNext()){
	Map.Entry<String,Integer> me=it.next();
	if(me.getValue().equals(102)){
	System.out.println("vallue 102 exist");
	}}
	set =map.entrySet();
	it=set.iterator();
	while (it.hasNext()){
	Map.Entry<String,Integer> me=it.next();
	System.out.println(me);
	}
	}
	
}