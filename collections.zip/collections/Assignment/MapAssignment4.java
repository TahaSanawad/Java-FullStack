import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Scanner;

class CountryMap {
	private HashMap<String, String> M1;
	
	public CountryMap() {
		M1 = new HashMap<String, String>();
	}
	
	public HashMap<String, String> saveCountryCapital(String CountryName, String capital) {
		M1.put(CountryName, capital);
		return M1;
	}
	
	public String getCapital(String CountryName) {
		return M1.get(CountryName);
	}
	
	public String getCountry(String capitalName) {
		Set<Entry<String, String>> set = M1.entrySet();
		Iterator<Entry<String, String>> it = set.iterator();
		
		while (it.hasNext()) {
			Map.Entry<String, String> me = it.next();
			
			if (me.getValue().equals(capitalName))
				return me.getKey();
		}
		
		return "Do not exist";
	}
	
	public HashMap<String, String> swapKyeValue() {
		HashMap<String, String> M2 = new HashMap<String, String>();
		
		Set<Entry<String, String>> set = M1.entrySet();
		Iterator<Entry<String, String>> it = set.iterator();
		
		while (it.hasNext()) {
			Map.Entry<String, String> me = it.next();
			M2.put(me.getValue(), me.getKey());
		}
		
		return M2;
	}
	
	public ArrayList<String> toArrayList() {
		ArrayList<String> list = new ArrayList<>();
		
		Set<Entry<String, String>> set = M1.entrySet();
		Iterator<Entry<String, String>> it = set.iterator();
		
		while (it.hasNext()) {
			Map.Entry<String, String> me = it.next();
			list.add(me.getKey());
		}
		
		return list;
	}
}
public class MapAssignment4{
	public static void main(String[] args){
	CountryMap cm=new CountryMap();
	Scanner sc=new Scanner(System.in);
	cm.saveCountryCapital("India","Delhi");
	cm.saveCountryCapital("Srilanka","Colombo");
	cm.saveCountryCapital("Pakistan","Islamabad");
	cm.saveCountryCapital("Austrelia","Canberra");
	System.out.println("please enter the name of coutry u want to search");
	String str1=sc.next();
	System.out.println(cm.getCapital(str1));
	System.out.println("please enter the name of capital u want to search");
	String str2=sc.next();
	System.out.println(cm.getCountry(str2));
	System.out.println(cm.toArrayList());
	
	HashMap<String,String> m2=cm.swapKyeValue();
	System.out.println(m2);
	}
}