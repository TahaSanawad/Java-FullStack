import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;
import java.util.Set;
import java.util.Map.Entry;
public class MapAssignment2{
	public static void main(String[] args){
	Map<String,String> map=new HashMap<>();
	map.put("Madhya Pradesh","Bhopal");
	map.put("Maharashtra","Mumbai");
	map.put("Uttar Pradesh","Lucknow");
	
	Set<Entry<String,String>> set=map.entrySet();
	Iterator<Entry<String,String>> it = set.iterator();
	

	set =map.entrySet();
	it=set.iterator();
	while (it.hasNext()){
	Map.Entry<String,String> me=it.next();
	System.out.println(me);
	}
	}
	
}