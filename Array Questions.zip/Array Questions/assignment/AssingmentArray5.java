class AssingmentArray5
{
	public static void main(String []args)
	{
		//ARRAY 1D SUM & AVG
	int array1[]= new int[]{5,4,3,2,6,1};
	int n=array1.length;
	int temp=0;
	
	
	for(int i=0;i<array1.length;i++){
		for(int j=1;j<n;j++){
			if(array1[j-1]>array1[j]){
				temp=array1[j-1];
				array1[j-1]=array1[j];
				array1[j]=temp;
			}				
		}
	}
	for(int i=0;i<array1.length;i++){
		System.out.println(array1[i]);
	 
	
	
		}
	}



}