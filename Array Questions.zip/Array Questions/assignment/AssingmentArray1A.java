class AssingmentArray1A
{
	public static void main(String []args)
	{
		//ARRAY 1D SUM & AVG
	int array1[]= new int[]{1,2,3,4,5};
	int sum=0;
	for(int i=0;i<array1.length;i++){
		sum=sum+array1[i];
	}
	System.out.println("sum of 1D Array: " + sum);
	System.out.println("Average of 1D Array: " + sum/array1.length);
	
	 
	
	
	}



}