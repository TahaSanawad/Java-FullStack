class AssingmentArray12
{
	public static void main(String []args)
	{
	int arr[]=new int[]{2,3,4,5,6,7,8,9};
	int counteven=0, countodd=0;
	for(int i=0;i<arr.length;i++){
		if(arr[i]%2==0)
			counteven++; 
		else 
			countodd++;
			  
		}
	int evenarr[]= new int[counteven]; 
	int oddarr[]= new int[countodd];
	int j=0,k=0;
	for(int i=0;i<arr.length;i++){
		if (arr[i]%2==0){
			evenarr[j]=arr[i];
			j++;}
		else {
			oddarr[k]=arr[i];
			k++;
			}
		}
	for(int i=0;i<counteven;i++){
		arr[i]=evenarr[i];
		}
	int l=counteven;
	for(int i=0;i<countodd;i++){
		arr[l]=oddarr[i];
		l++;
		}
	for(int i=0;i<arr.length;i++){
		
		System.out.println(arr[i]);	 
		}
	}


}