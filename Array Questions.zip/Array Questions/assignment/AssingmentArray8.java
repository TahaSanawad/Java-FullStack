class AssingmentArray8
{
	public static void main(String []args)
	{
		//ARRAY 1D SUM & AVG
	int array1[]= new int[]{1,1,4,4,};
	int count=0;
	for(int i=0;i<array1.length;i++){
		if(array1[i]==1)
			count=count+1;
		else if (array1[i]==4)
			count = count+1;
	
	}
	if(count==array1.length)
		System.out.println("True");
	else
		System.out.println("False");
	 
	
	
	}



}