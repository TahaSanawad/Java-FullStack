class AssingmentArray3
{
	public static void main(String []args)
	{
		//ARRAY 1D SUM & AVG
	int array1[]= new int[]{1,2,3,4,5};
	int a= Integer.parseInt(args[0]);
	int count=0;
	int j = 0;
	for(int i=0;i<array1.length;i++){
		j=j+1;
		if(array1[i]==a)
			
			count=count + 1;
	}
	
	 
	if(count==0)
		System.out.println("not found:-1");
	else if (count==1)
		System.out.println("the element" + a + "is present at this index: " + j);		
	
	}



} 