class AssingmentArray1B
{
	public static void main(String []args)
	{
		//ARRAY 2D SUM & AVG
	int array1[][]= new int[][]{{1,2,3,4,5},{1,2,3,4,5}};
	int sum=0;
	for(int i=0;i<array1.length;i++){
		for(int j=0;j<array1[0].length;j++)
			sum=sum+array1[i][j];
	}
	System.out.println("sum of 2D Array: " + sum);
	System.out.println("avg of 1D Array: " + sum/(array1[0].length+array1[1].length));
	
	
	}



}