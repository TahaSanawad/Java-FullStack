class AssingmentArray4
{
	public static void main(String []args)
	{
		//ARRAY 1D SUM & AVG
	int array1[]= new int[]{5,4,3,2,6,1};
	int n=array1.length;
	int temp=0;
	
	
	for(int i=0;i<array1.length;i++){
		for(int j=1;j<n;j++){
			if(array1[j-1]>array1[j]){
				temp=array1[j-1];
				array1[j-1]=array1[j];
				array1[j]=temp;
			}				
		}
	}
		System.out.println("The two max elements are: " + array1[n-1] +" " + array1[n-2] );
		System.out.println("The two min elements are: " + array1[0] + " " + array1[1]);
	 
	
	
		
	}



}