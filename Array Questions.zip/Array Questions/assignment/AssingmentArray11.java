class AssingmentArray11
{
	public static void main(String []args)
	{
	int a[]=new int[]{1,2,3};
	int b[]=new int[]{4,5,6};
	int arr[]=new int[2];
	int len1=a[a.length/2];
	int len2=b[b.length/2];
	arr[0]=len1;
	arr[1]=len2;
	System.out.println(arr[0]+ " " + arr[1]);
	}
}