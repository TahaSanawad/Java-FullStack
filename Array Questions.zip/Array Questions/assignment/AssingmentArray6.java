class AssingmentArray6
{
	public static void main(String []args)
	{
		//ARRAY 1D SUM & AVG
	int array1[]= new int[]{1,1,4,4,5,6,7,8,2,3};
	
	int n = array1.length;
	int temp[] = new int[n];
	int temp1=0;
	for(int i=0;i<array1.length;i++){
		for(int j=1;j<n;j++){
			if(array1[j-1]>array1[j]){
				temp1=array1[j-1];
				array1[j-1]=array1[j];
				array1[j]=temp1;
			}				
		}
	}
	int j = 0;
	for(int i=0;i<n - 1 ;i++){
		if(array1[i]!=array1[i+1]){
			temp[j++]=array1[i];
		}
	}
	 
	temp[j++]=array1[n-1];
	for(int i=0;i<n - 1 ;i++){
		System.out.print(temp[i] + " ");
	
	}
	}



}