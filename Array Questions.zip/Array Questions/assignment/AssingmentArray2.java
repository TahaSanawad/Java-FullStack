class AssingmentArray2
{
	public static void main(String []args)
	{
		//ARRAY 1D MIN MAX
	int array1[]= new int[]{1,2,3,4,5};

	int max=0;
	for(int i=0;i<array1.length;i++){
		if (array1[i]>max)
			max = array1[i];
	}
	int min=999;
	for(int i=0;i<array1.length;i++){
		if (array1[i]<min)
			min = array1[i];
			
	}
	
	System.out.println("Max of Array: " + max + " & Min of Array: " + min);
	
	
	}



}