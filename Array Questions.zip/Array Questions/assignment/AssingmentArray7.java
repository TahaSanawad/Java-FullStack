class AssingmentArray7
{
	public static void main(String []args)
	{
		//ARRAY sum
	int array1[]= new int[]{10,3,6,1,2,7,9};
	int n=array1.length;
	int flag=1;
	int sum=0;
	
	
	for(int i=0;i<array1.length;i++){
		if(array1[i]!=6 && flag==1)
			sum=sum+array1[i];
		else if(array1[i]==6)
			flag=0;
		else if(array1[i]==7)
			flag=1;
		}

		System.out.println("sum wthout number between 6 & 7 : " + sum );
	 
	
	
	}



}