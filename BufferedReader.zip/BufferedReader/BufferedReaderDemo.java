import java.io.BufferedReader;
import java.io.InputStreamReader;
class BufferedReaderDemo
{
	public static void main(String[] args) throws Exception{
	InputStreamReader is=new InputStreamReader(System.in);
	BufferedReader br = new BufferedReader(is);
	String name=br.readLine();
	System.out.println(name);
	}
	


}