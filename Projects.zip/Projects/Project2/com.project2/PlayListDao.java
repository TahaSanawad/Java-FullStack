import java.sql.Connection;
import java.sql.PreparedStatement;

public class PlayListDao {
	public static boolean insertSongToDB(String string, String d, String string2){
    
    boolean flag=false;
    try{
        Connection con=ConnectionJDBC.createC();
        String q = "insert into playlist(title,duration,artist) values(?,?,?)";
        PreparedStatement pstmt= con.prepareStatement(q);
        pstmt.setString(1,string);
        pstmt.setString(2, d);
        pstmt.setString(3,string2);
        //execute
        pstmt.executeUpdate();
        flag=true;
    }
    
    
    catch(Exception e){
        

    }
    return flag;
}
	public static boolean deleteSong(String string) {
		 boolean flag=false;
		    try{
		        Connection con=ConnectionJDBC.createC();
		        String q = "delete from playlist where title=?";
		        PreparedStatement pstmt= con.prepareStatement(q);
		        pstmt.setString(1,string);
		        //execute
		        pstmt.executeUpdate();
		        flag=true;
		    }
		    
		    
		    catch(Exception e){
		        

		    }
		    return flag;
		
	}

}

