
import java.sql.Connection;
import java.sql.PreparedStatement;

public class SongsDao {
  

    public static boolean insertSongToDB(String string, String d, String string2){
        
        boolean flag=false;
        try{
            Connection con=ConnectionJDBC.createC();
            String q = "insert into songs(title,duration,artist) values(?,?,?)";
            PreparedStatement pstmt= con.prepareStatement(q);
            pstmt.setString(1,string);
            pstmt.setString(2, d);
            pstmt.setString(3,string2);
            //execute
            pstmt.executeUpdate();
            flag=true;
            

        }
        catch(Exception e){
            e.printStackTrace();

        }
        return flag;
    }
    
}
