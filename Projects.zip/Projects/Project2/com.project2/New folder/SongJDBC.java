//database = project & table = songs
public class SongJDBC {
    private String songTitle;
    private String songDuration;
    private String songArtist;
    public SongJDBC(String songTitle, String songDuration,String songArtist){
        super();
        this.setSongTitle(songTitle);
        this.setSongDuration(songDuration);
        this.setSongArtist(songArtist);
    }
 /*   public SongJDBC(String songTitle, String songArtist){
        super();
        this.setSongTitle(songTitle);
        this.setSongArtist(songArtist);
    }*/
    public String getSongArtist() {
        return songArtist;
    }
    public void setSongArtist(String songArtist) {
        this.songArtist = songArtist;
    }
    public String getSongDuration() {
        return songDuration;
    }
    public void setSongDuration(String songDuration) {
        this.songDuration = songDuration;
    }
    public String getSongTitle() {
        return songTitle;
    }
    public void setSongTitle(String songTitle) {
        this.songTitle = songTitle;
    }
    public String toString(){
        return "songs [songTitle=" + songTitle + ",songDuration= " + songDuration + ",songArtist= " +songArtist +"]";
    }


    
}
