
public class PlayListJDBC {
	private int track_number;
	private String songTitle;
    private String songDuration;
    private String songArtist;
    public PlayListJDBC(String songTitle, String songDuration,String songArtist){
        super();
    	this.songTitle=songTitle;
        this.songDuration=songDuration;
        this.songArtist=songArtist;
    }
	public int getTrack_number() {
		return track_number;
	}
	public void setTrack_number(int track_number) {
		this.track_number = track_number;
	}
	public String getSongTitle() {
		return songTitle;
	}
	public void setSongTitle(String songTitle) {
		this.songTitle = songTitle;
	}
	public String getSongArtist() {
		return songArtist;
	}
	public void setSongArtist(String songArtist) {
		this.songArtist = songArtist;
	}
	public String getSongDuration() {
		return songDuration;
	}
	public void setSongDuration(String songDuration) {
		this.songDuration = songDuration;
	}
    public String toString(){
        return "PlayList  [ track_number" + track_number + "songTitle=" + songTitle + ",songDuration= " + songDuration + ",songArtist= " +songArtist +"]";
    }



}
