package com.project;
import com.project.MobilePhone;
import com.project.LandLine;
public class Main{
    public static void main(String[] args){
        LandLine myPhone=new LandLine("123456");
        myPhone.powerOn();
        myPhone.callPhone("123456");
        myPhone.answer();

        MobilePhone myPhone2=new MobilePhone("12345");
        myPhone2.callPhone("12345");
        myPhone2.powerOn();
        myPhone2.callPhone("1234");
        myPhone2.callPhone("12345");
        myPhone2.answer();



    }
}