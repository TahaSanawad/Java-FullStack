package com.project;
import com.project.Telephone;
public class MobilePhone implements Telephone{
    private String myNumber;
    private boolean isRinging;
    private boolean isPowerOn;
    private boolean isScreenOn;

    public MobilePhone(String myNumber){
        this.myNumber=myNumber;
    }
    public void powerOn(){
        isPowerOn=true;
        System.out.println("Phone powered onn");
    }
   /* public void screenOn(String pswd){
        if(pswd==)
    }*/
    public void dial(String phoneNumber){
        System.out.println("Now Ringing");
    }
    public void answer(){
        if(isRinging && isPowerOn){
            System.out.println("Ansering Phone");
            isRinging=false;
        }else{
           
        }
    }
    public boolean callPhone(String phoneNumber){
        if(phoneNumber==myNumber && isPowerOn){
        isRinging=true;
        System.out.println("phone is ringing");
        }else{
            System.out.println("Wrong number or phone is off");
            isRinging=false;
        }
        return isRinging;
    }
    public boolean isRinging(){
        return isRinging;
    }
    
}