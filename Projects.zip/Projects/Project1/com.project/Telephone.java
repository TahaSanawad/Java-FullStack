package com.project;
public interface Telephone{
    //powerOn
    //dial a number
    //call another phone
    //its ringing
    void powerOn();
    void dial(String phoneNumber);
    void answer();
    boolean callPhone(String phoneNumber);
    boolean isRinging();
}