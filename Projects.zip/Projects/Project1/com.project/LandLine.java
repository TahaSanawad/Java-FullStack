package com.project;
import com.project.Telephone;
public class LandLine implements Telephone{
    private String myNumber;
    private boolean isRinging;
    public LandLine(String myNumber){
        this.myNumber=myNumber;
    }
    public void powerOn(){
        System.out.println("LandLine is always powered");
    }
    public void dial(String phoneNumber){
        System.out.println("Now Ringing");
    }
    public void answer(){
        if(isRinging){
            System.out.println("Ansering the LandLine");
            isRinging=false;
        }else{
            System.out.println("Phone is not ringing");
        }
    }
    public boolean callPhone(String phoneNumber){
        if(phoneNumber==myNumber){
        isRinging=true;
        System.out.println("phone is ringing");
        }else{
            isRinging=false;
        }
        return isRinging;
    }
    public boolean isRinging(){
        return isRinging;
    }
    
}