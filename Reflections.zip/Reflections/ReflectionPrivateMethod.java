package com.reflex;
import java.lang.reflect.Method;
public class ReflectionPrivateMethod{
	public static void main(String [] args)
	{
		Class c=Class.forname("com.reflex.Test");
		Test t=(Test)c.newInstance();
		Method m = c.getDeclareMethod("show",null);
		m.setAccessible(true);
		m.invoke(t,null);
	}

}