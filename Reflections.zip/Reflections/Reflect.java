import java.lang.*;
public class Reflect{
public static void main(String[] args){
try{
	Class cls=Class.forName("java.lang.String");
	System.out.println(cls.getName());
	Object s= new String("yash");
	Class a=s.getClass();
	System.out.println(a.getName());
	System.out.println(Reflect.class.getName());
	}
catch(Exception e){
	System.out.println(e);
	}
	}
}
