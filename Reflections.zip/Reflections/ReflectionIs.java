import java.lang.*;
class ReflectionIs{
public static void main(String [] args){
 int a[]={1,2,3,4,5,6,7};
 Class class1=a.getClass();
 System.out.println(class1.isArray());
 System.out.println(class1.isPrimitive());

 }}