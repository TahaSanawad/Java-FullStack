import React,{Component} from 'react';
class About extends Component
{
    render()
    {
        return(
            <div className='about'>
                <p>This is the about us page</p>
            </div>           
        );
    }
}
export default About