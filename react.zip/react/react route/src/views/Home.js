import React,{Component} from 'react';
class Home extends Component
{
    render()
    {
        return(
            <div className='about'>
                <p>This is the home page</p>
            </div>           
        );
    }
}
export default Home