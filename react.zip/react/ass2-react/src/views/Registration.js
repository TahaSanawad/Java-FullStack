import  React,{Component} from 'react';
class Registration extends Component
{
    render()
    {
        return(
            <div className='registrationform'>
                <form>
                    <label>Username</label><br></br>
                    <input type="text" placeholder='Enter your username' /><br></br>
                    <label>Email id:</label><br></br>
                    <input type="email" placeholder='Enter email id here' /><br></br>
                    <label>Password</label>
                    <input type="password" placeholder='Enter your password here' /><br></br>
                    <label>Gender</label><br></br>
                    <input type="radio" id="gender" value="male" />
                    <label for="male">Male</label><br></br>
                    <input type="radio" id="gender" value="female" />
                    <label for="female">Female</label><br></br>
                    <input type="submit" value="Submit" />
                </form>
            </div>
        );
    }
}
export default Registration