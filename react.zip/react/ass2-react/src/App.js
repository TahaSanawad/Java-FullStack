import Login from './views/Login';
import Registration from './views/Registration';
import './App.css';

function App() {
  return (
    <div className='content'>
      <Login />
      <Registration />
    </div>
  );
}

export default App;
