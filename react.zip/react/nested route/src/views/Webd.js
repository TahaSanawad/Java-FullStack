import React,{Component} from "react";
class Webd extends Component
{
    render()
    {
        return(
            <div className="webd">
                <p>Providing solutions through website development</p>
            </div>
        );
    }
}
export default Webd