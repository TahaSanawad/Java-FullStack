import Menu from './views/Menu';
import LeftContent from './views/LeftContent';
import RightContent from './views/RightContent';
import News from './views/News';
import Testimonial from './Testimonials';
import LoginForm from './LoginForm';
import './App.css';

function App() {
  return (
     <div className='wrapper'>
   <Menu />
   <div className='content'>
   <LeftContent />
   <RightContent />
   </div>
   <div className='footertop'>
    <News />
    <Testimonial />
<LoginForm />
   </div>
   </div>
  );
}

export default App;
