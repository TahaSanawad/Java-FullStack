import React,{Component} from 'react';
class News extends Component
{
    render()
    {
    return(
        <div className="news">
        <ul>
        <li>Monsoon is touching indore</li>
        <li>mnc election is going on</li></ul>
        </div>
    );
    }
}
export default News