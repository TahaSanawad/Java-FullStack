import React,{Component} from "react";
class RightContent extends Component
{
    render()
    {
         return(
            <div className="rcontent">
                right content
            </div>

         );
    }
}
export default RightContent