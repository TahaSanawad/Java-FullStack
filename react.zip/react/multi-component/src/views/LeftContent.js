import React, {Component} from 'react';
class LeftContent extends Component
{
  render()
  {
    return (
        <div className='lcontent'>
                 
  left content
        </div>

    );
  }
}
export default LeftContent