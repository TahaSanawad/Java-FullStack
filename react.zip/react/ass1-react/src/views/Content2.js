import React,{Component} from "react";
class Content2 extends Component
{
    render()
    {
        return(
            <div className="content2">
                This is content2 area
            </div>
        );
    }
}
export default Content2