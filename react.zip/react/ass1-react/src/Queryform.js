
import React, {Component} from 'react';
class Queryform extends Component
{
  render()
  {
    return (
        <div className='queryform'>
            <form>
                <label>Email<input type="text" /></label>
                <br />
                <label>Employee id<input type="text" /></label> 
                <br />
                <label>Query<input type="text" /></label><br />
                <input type="submit" value="Submit" />
            </form>
        </div>

    );
  }
}
export default Queryform