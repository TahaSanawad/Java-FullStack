import java.util.InputMismatchException;
import java.util.Scanner;
class ExceptionAssignment3
{	public static void main(String [] args){
	Scanner sc=new Scanner(System.in);
	System.out.println("ENTER THE NUMBER OF ELEMENTS U WANT IN ARRAY: ");
	int n = sc.nextInt();
	int arr[]=new int[n];
	System.out.println("Enter the elements of the array: ");
	
	try{
		for(int i=0;i<n;i++){
	arr[i]=sc.nextInt();
	}
	System.out.println("enter the index of the array element u want");
	int index=sc.nextInt();
		int ans = arr[index];
	System.out.println("The array element at index=" + index + " is= " + ans );
	
	
	}
	catch (InputMismatchException e){
		System.out.println("enter all the elements of type integer");
	}
	catch(ArrayIndexOutOfBoundsException e){
	System.out.println("enter the proper index in the range 0 to "+ n);
	
	}
	}
}
	
