class  ExceptionAssignment5
{
	public static void main(String [] args){
	try{
	System.out.println(100/0);
	
	}
	catch(ArithmeticException e)
	{
		System.out.println("not possibe to divide a number by zero");
	}
}
}