import java.util.Scanner;
class ExceptionAssignment2
{	public static void main(String [] args){
	Scanner sc=new Scanner(System.in);
	System.out.println("ENTER THE NUMBER OF ELEMENTS U WANT IN ARRAY: ");
	int n = sc.nextInt();
	int arr[]=new int[n];
	System.out.println("Enter the elements of the array: ");
	for(int i=0;i<n;i++){
	arr[i]=sc.nextInt();
	}
	System.out.println("enter the index of the array element u want");
	int index=sc.nextInt();
	try{
		int ans = arr[index];
	System.out.println("The array element at index=" + "3" + " is= " + ans );
	
	
	}
	catch(ArrayIndexOutOfBoundsException e){
	System.out.println("enter the proper index in the range 0 to "+ n);
	
	}
	}
}
	

