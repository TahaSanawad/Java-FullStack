import java.util.Scanner; //bhul jata me yaad rakhna hai
class ExceptionAssignment1
{
	public static void main(String [] args){
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number : ");
		String str = sc.next();
		try{
		 int num = Integer.parseInt(str);
		 System.out.println("Square of entered number is : " + num*num);
		}
		catch(NumberFormatException e)
		{
		System.out.println("bhiyao!! please enter an integer");
		}
}


}