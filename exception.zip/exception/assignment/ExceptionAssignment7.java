class InvalidCountryException extends Exception{
	public InvalidCountryException(){
	super();
	System.out.println("Only indian citizen can register");
	}}

class ExceptionAssignment7{
	
	public void registerUser(String username, String userCountry) throws InvalidCountryException {
		if (!userCountry.equals("India"))
			throw new InvalidCountryException();
		else
			System.out.println("User registration done successfully");
		
		
	}

	public static void main(String[] args) {
		ExceptionAssignment7 registration = new ExceptionAssignment7();
		
		try {
			//registration.registerUser("Mickey", "US");
			registration.registerUser("Mini", "India");
		} catch (InvalidCountryException e) {
			System.out.println(e.getMessage());
		}
	}

}