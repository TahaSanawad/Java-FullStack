
class ExceptionCheckedDemo4
{
	public static void main(String[] args){
	try
	{
	String s="acb";
	int i = Integer.parseInt(s);
	}
	catch(Exception e)
	{System.out.println(e);
	}
	
	
	
	
	/* this is checked exception 
	without try catch OUTPUT= 
	Exception in thread "main" java.lang.NumberFormatException: For input string: "acb"
        at java.lang.NumberFormatException.forInputString(NumberFormatException.java:65)
        at java.lang.Integer.parseInt(Integer.java:580)
        at java.lang.Integer.parseInt(Integer.java:615)
        at ExceptionCheckedDemo4.main(ExceptionCheckedDemo4.java:7)
	with try catch */
}
}