import java.io.*;
class CheckedException
{
public static void main(String[] args)throws IOException
{	

	try{
		File file=new File("Notexist.txt");
		FileInputStream stream = new FileInputStream(file);
	}
	catch(FileNotFoundException e1){
		System.out.println(e1);
		System.out.println("--------------------------------");
	}
	
	
	try{
		Class.forName("hzhzhz");
	}
	catch(ClassNotFoundException e3)
	{
		System.out.println(e3);
		System.out.println("--------------------------------");
		
	}
	
	DataInputStream dis = new DataInputStream(new FileInputStream("d:/xyz.txt"));
	while(true){
		char ch;
		try{ch=dis.readChar();
			System.out.print(ch);
		}
		catch (EOFException e2){
			System.out.println("");
			System.out.println(e2);
			break;
		}
	}

		

}


}