class ThrowsDemo2{
	static void checkAge(int age) throws ArithmeticException{
	
	if(age<18){
	throw new ArithmeticException("AGE must be above 18");
	
	}
	else{
	System.out.println("Elegible");
	}
	}
	public static void main(String[] args)
	{
	checkAge(15);
	}
}