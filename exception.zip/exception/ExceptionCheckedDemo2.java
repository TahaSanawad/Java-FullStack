import java.io.FileInputStream;
class ExceptionCheckedDemo2
{
	public static void main(String[] args){
	try
	{FileInputStream f=new FileInputStream("D:/xyz.txt");
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
	/*
	OUTPUT without try catch=
	ExceptionCheckedDemo2.java:5: error: unreported exception FileNotFoundException; must be caught or declared to be thrown
        FileInputStream f=new FileInputStream("D:/xyz.txt");
                          ^
	1 error
	*/
	
	}
}