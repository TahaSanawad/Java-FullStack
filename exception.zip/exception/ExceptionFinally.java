class ExceptionFinally
{
	public static void main(String[] args)
	{
		try
		{
			System.out.println(9);
		}		
		finally{
		 System.out.println("we r in finally block");
		
		}
	}
}