class ExceptionMessage
{
	public static void main(String[] args)
	{
		try
		{
			System.out.println(9/0);
		}
		catch(ArithmeticException e)
		{
		//e.printStackTrace();
		/* exception name, description,stacktrace(line)
		output=
		java.lang.ArithmeticException: / by zero
        at ExceptionMessage.main(ExceptionMessage.java:7) */
		//System.out.println(e);
		/*only name and description
		output=
		java.lang.ArithmeticException: / by zero*/
		System.out.println(e.getMessage());
		/* description only
		output=
		/ by zero
		*/
		
		}
	
	
	}
}