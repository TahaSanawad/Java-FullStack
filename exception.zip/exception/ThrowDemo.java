import java.util.Scanner;
class VoteEligibility extends RuntimeException
{ VoteEligibility(String s)
	{
		super(s);
	}
}

class ThrowDemo{
public static void main(String[] args){
	Scanner s = new Scanner(System.in);
	System.out.println("enter age");
	int age=s.nextInt();
	
	try
	{if(age<18)
	{
	 throw new VoteEligibility("You are not eligible for voting");
	}
	else{
	System.out.println("you can vote");
	}
	}
	catch(VoteEligibility e)
	{
		System.out.println(e);
	}
}
	

}