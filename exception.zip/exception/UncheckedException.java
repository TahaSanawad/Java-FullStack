class UncheckedException
{
	public static void main(String [] args)
	{
	try
	{
		String s=null;
		System.out.println(s.length());//NullPointerException
	}
		catch(NullPointerException np){
		System.out.println(np);
		
	}
	try{
		
		int a=50/0;//Arithmetic Exception
	}
	catch(ArithmeticException ae){
		System.out.println(ae);
	}
	
	try{
		String str1="abc";
		int i2 = Integer.parseInt(str1);//NumberFormatException
	}
	catch(Exception ae){
		System.out.println(ae);
	}

	try{
		
		int arr[]=new int[5];
		arr[7]=54;//ArrayIndexOutOfBoundsException
	}
		catch(ArrayIndexOutOfBoundsException an){
		System.out.println(an);
	}
	
	finally{
	try{
		String str="yash technology";
		System.out.println(str.charAt(119));//StringIndexOutOfBoundsException
	}
		catch(Exception si){
		System.out.println(si);
	}
	}
}

}