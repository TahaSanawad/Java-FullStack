class ExceptionDemo1
{
	public static void main(String [] args){
	System.out.println("Yash ");
	System.out.println("Technologies");
	//System.out.println(100/0);
	/* 
	THIS IS UNCHECK EXCEPTION 
	OUTPUT=
	Yash
	Technologies
	Exception in thread "main" java.lang.ArithmeticException: / by zero*/
	
	}
}