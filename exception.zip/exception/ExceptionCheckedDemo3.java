
class ExceptionCheckedDemo3
{
	public static void main(String[] args){
	
	try
	{String str=null;
	System.out.println(str.length());
	
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
	
/*  this is unchecked excepton
	without trycatch output=
		Exception in thread "main" java.lang.NullPointerException
		at ExceptionCheckedDemo3.main(ExceptionCheckedDemo3.java:8)
		
	with try catch output= 
		java.lang.NullPointerException
}