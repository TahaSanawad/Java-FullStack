class EnumOrdinalDemo
{
	enum Directions{
		EAST,WEST,NORTH,SOUTH;	
	}
	public static void main(String[] args){
		//Directions d= Directions.EAST;
		//System.out.println(d);
		for(Directions d:Directions.values())
		{
			System.out.println(d);
			
		}
		System.out.println("Value of: "+ Directions.valueOf("WEST"));// WEST
		System.out.println("Value of: "+ Directions.valueOf("NORTH").ordinal());//2
	}


}