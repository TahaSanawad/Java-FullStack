enum Animal{
	dog,cat,lion,tiger
}
public class EnumSwitchDemo{
public static void main(String[] args){
	for(Animal b:Animal.values()){
	switch(b){
	case dog:
		System.out.println("dog");
		System.out.println("Value of: "+ Animal.valueOf("dog").ordinal());
		break;
	case cat:
		System.out.println("cat");
		System.out.println("Value of: "+ Animal.valueOf("cat").ordinal());
		break;
	case lion:
		System.out.println("lion");
		System.out.println("Value of: "+ Animal.valueOf("lion").ordinal());
		break;
	case tiger:
		System.out.println("tiger");
		System.out.println("Value of: "+ Animal.valueOf("tiger").ordinal());
		break;
	}
	}
	
	}

}