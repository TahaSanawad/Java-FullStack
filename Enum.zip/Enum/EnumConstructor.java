enum Seasons{
	SUMMER("summer season"),WINTER("winter season"),SPRING("Spring season"),AUTUMN("Autumn season"),MONSOON("mnsoon season");
	public final String s;
	private Seasons(String s){
		this.s=s;
	}
	public String getSeasons(){
		return s;
	}
}
public class EnumConstructor{
public static void main(String[] args){
Seasons s=Seasons.SUMMER;
System.out.println(s.getSeasons());

}
}