import java.sql.*;
import java.io.*;
class JdbcImageDemo
{
		public static void main(String[] args)
		{
			try
			{ 
				Class.forName("com.mysql.jdbc.Driver");
				/*String url = "jdbc:mysql://localhost:3306/youtube";
				String user = "root";
				String pass ="root";*/
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/youtube","root","root");
				String q="insert into images(pic) values(?)";
				PreparedStatement pstmt=con.prepareStatement(q);
				FileInputStream fis= new FileInputStream("Screenshot (141).png");
				pstmt.setBinaryStream(1,fis,fis.available());
				pstmt.executeUpdate();
				System.out.println("done....");
				if(con!=null)
				{
					System.out.println("connection successfull");
				}
				else
				{
					System.out.println("connection unsuccessfull");
				} 
			}
			catch(Exception e){
				System.out.println(e);
			}
				
		}
}