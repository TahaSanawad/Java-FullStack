import java.sql.*;
class FirstJdbcDemo
{
		public static void main(String[] args)
		{
			try
			{
				Class.forName("com.mysql.jdbc.Driver");
				String url = "jdbc:mysql://localhost:3306/yash";
				String user = "root";
				String pass ="root";
				String sql = "update employee set name='Taha Updated' where empID=1001";
				String sql2 = " insert into employee values(1004,'executeQuery')";
				
				Connection con = DriverManager.getConnection(url,user,pass);
				if(con!=null)
				{
					System.out.println("connection successfull");
				}
				else
				{
					System.out.println("connection unsuccessfull");
				} 
				
				String q="select * from employee";
				Statement st = con.createStatement();
				st.executeUpdate(sql);//this will update the name taha to taha update
				st.executeUpdate(sql2);// this will add extra column into the database
				ResultSet set = st.executeQuery(q);
				while(set.next())
				{
					int id =set.getInt("empID");
					String name=set.getString("name");
					System.out.println("id:" + id);
					System.out.println("name: " + name);
					
				}
				con.close();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
}