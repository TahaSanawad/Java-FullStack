public class ThreadDemo2 extends Runnable{
	public void run()
	{
	 System.out.println("Thread Started");
	}
	public static void main(String[] args){
	Thread t1=new Thread(new ThreadDemo2());
	t1.start();
	//t.start(); cannot write twice will give error
	}
}