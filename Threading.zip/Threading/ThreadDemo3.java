//single task single thread
public class ThreadDemo3 extends Thread{
	public void run()
	{
	 System.out.println("Thread Started");
	}
	public static void main(String[] args){
	ThreadDemo t=new ThreadDemo();
	t.start();
	//t.start(); cannot write twice will give error
	}
}