public class ThreadSleepDemo{
	public static void main(String[] args){
	try{
		for(int i =1;i<=5;i++){
			Thread.sleep(1200);
			System.out.println(i);
		}
	
	}
	catch(	Exception e){
		e.printStackTrace();
	}
	}

}