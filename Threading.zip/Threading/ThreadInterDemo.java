public class ThreadInterDemo extends Thread{
public void run(){
	//System.out.println(Thread.interrupted());
	//System.out.println(Thread.interrupted());
	//System.out.println(Thread.interrupted());
	//System.out.println(Thread.currentThread().isInterrupted());
	for(int i=0;i<4;i++){
		try{
		System.out.println(i);
		//System.out.println(Thread.currentThread().isInterrupted());
		//System.out.println(Thread.interrupted());
		Thread.sleep(1000);
		//System.out.println(Thread.interrupted());
		//System.out.println(Thread.currentThread().isInterrupted());
		
		}
		catch(Exception e){
			System.out.println(e);
		}
		}
	}
public static void main(String[] args){
	ThreadInterDemo td=new ThreadInterDemo();
	td.start();
	td.interrupt();
	
}
}