//multiple thread multiple task
class MyThread1 extends Thread{
public void run()
	{
	 System.out.println("Thread1 Started");
	}
}
class MyThread2 extends Thread{
public void run()
	{
	 System.out.println("Thread2 Started");
	}
}
class MyThread3 extends Thread{
public void run()
	{
	 System.out.println("Thread3 Started");
	}
}
public class ThreadDemo5 {
	public static void main(String[] args){
	MyThread1 t1=new MyThread1();
	t1.run();
	MyThread2 t2=new MyThread2();
	t2.run();
	MyThread3 t3=new MyThread3();
	t3.run();
	}
	}