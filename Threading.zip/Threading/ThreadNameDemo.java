public class ThreadNameDemo extends Thread{
public void run()
{
	Thread.currentThread().setName("Run");
	System.out.println("Run :" + Thread.currentThread().getName());
}
public static void main(String[] args){
System.out.println(  Thread.currentThread().getName());
ThreadNameDemo t1= new ThreadNameDemo();
System.out.println("after making t1 object "+t1.isAlive());
t1.setName("Thread t1");
System.out.println(t1.isAlive());
t1.start();

System.out.println(Thread.currentThread().isAlive());


ThreadNameDemo t2= new ThreadNameDemo();
System.out.println(t2.isAlive());
t2.setName("Thread t2"); 
t2.start();
}

}