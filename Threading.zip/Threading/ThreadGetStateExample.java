public class ThreadGetStateExample extends Thread 
{  
   public void run()   
    {  
         
        Thread.State state = Thread.currentThread().getState();  
        System.out.println("Running thread name: "+ Thread.currentThread().getName());  
        System.out.println("State of thread: " + state);  
    }  
    public static void main(String args[])   
    {  
        ThreadGetStateExample t1 = new ThreadGetStateExample();  
		ThreadGetStateExample t2 = new ThreadGetStateExample();
		System.out.println("Running thread name: " + Thread.currentThread().getName());
        t1.start();     
        t2.start();  
    }  
} 