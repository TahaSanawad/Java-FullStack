//single task multiple thread
public class ThreadDemo4 extends Thread{
	public void run()
	{
	 System.out.println("Thread Started");
	}
	public static void main(String[] args){
	ThreadDemo t=new ThreadDemo();
	t.start();
		ThreadDemo t2=new ThreadDemo();
		t2.start();
	}
}