import javax.swing.*;  
public class SwingExample {  
public static void main(String[] args) {       
	JButton b=new JButton("click here ");  //2
	b.setBounds(50,200,200, 40); 
    JFrame f3= new JFrame("SwingExample 1");  
    JTextField t1,t2;  
    t1=new JTextField("Welcome to Yash Technologies");  //3
    t1.setBounds(50,100, 200,30);  
    t2=new JTextField("Swing Tutorial");  				//3
    t2.setBounds(50,150, 200,30);  
	JTextArea area=new JTextArea("Hey!!! Enter text here"); //4 
    area.setBounds(10,30,400,30);  
    f3.add(area);f3.add(t1); f3.add(t2);f3.add(b);        
	f3.setSize(400,500);
	f3.setLayout(null); 
	f3.setVisible(true); 


JFrame f2=new JFrame("SwingExample 2");
JLabel l1,l2;  
l1=new JLabel("Hello");							  //5
l1.setBounds(50,50, 100,30);  
l2=new JLabel("Welcome To Yash Technologies"); 		//5 
l2.setBounds(50,100, 1300,130);  
f2.add(l1); f2.add(l2);  
f2.setSize(400,500);  
f2.setLayout(null);  
f2.setVisible(true);  
}  
}  