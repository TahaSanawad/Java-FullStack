
import java.util.Random;
abstract class Compartment {
	abstract void notice();
}
class FirstClass extends Compartment{
	void notice(){
	System.out.println("you are in: Firstclass");
	}
	
}
class General extends Compartment{
	void notice(){
	System.out.println("you are in: Generalclass");
	}
	
}
class Ladies extends Compartment{
	void notice(){
	System.out.println("you are in: Ladies Coach");
	}
	
}
class Luggage extends Compartment{
	void notice(){
	System.out.println("you are in: Luggage Coach");
	}
	
}


class AssignmentAbstract2 {

	public static void main(String[] args) {
		Compartment[] compartments = new Compartment[10];

		Random rand = new Random();
	    
	    for (int i = 0; i < 10; i++) {
	    	int random = rand.nextInt(4);
	    	
	    	if (random+1 == 1)
	    		compartments[i] = new FirstClass();
	    	else if (random+1 == 2)
	    		compartments[i] = new Ladies();
	    	else if (random+1 == 3)
	    		compartments[i] = new General();
	    	else if (random+1 == 4)
	    		compartments[i] = new Luggage();
	    	
	    	compartments[i].notice();
	    }
	}

}
