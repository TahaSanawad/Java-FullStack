abstract class GeneralB
{
	public abstract double getSavingInterestRate();
	public abstract double getFixedInterestRate();
}

class ICICIBank extends GeneralB
{	
	public double getSavingInterestRate(){
		return 4.0;
	 }
	public double getFixedInterestRate(){
		return 8.5;
	 }

}
class KotMBank extends GeneralB
{	
	public double getSavingInterestRate(){
		return 4.0; 
	 }
	
	public double getFixedInterestRate(){
		return 7.0;
	 }

}
class AssignmentAbstract1 
{

	public static void main(String[] args) {
	ICICIBank iciciBank = new ICICIBank();		
	KotMBank kotMBank = new KotMBank();		
	GeneralB gb1 = new ICICIBank();		
	GeneralB gb2 = new KotMBank();
	System.out.println(iciciBank.getSavingInterestRate());		
	System.out.println(iciciBank.getFixedInterestRate());		
	System.out.println(kotMBank.getSavingInterestRate());		
	System.out.println(kotMBank.getFixedInterestRate());								
	System.out.println(gb1.getSavingInterestRate());		
	System.out.println(gb1.getFixedInterestRate());		
	System.out.println(gb2.getSavingInterestRate());		
	System.out.println(gb2.getFixedInterestRate());	
	}
}