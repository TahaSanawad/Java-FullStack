import javax.swing.JOptionPane;
public class JOptionPaneDemo2
{
	public static void main(String[] args)
{
	
	String input = JOptionPane.showInputDialog("blah blah blah");
	System.out.println("the input by user is: "+ input);
	String[] options={"as","ss","SS"};
int x	= JOptionPane.showOptionDialog(null,"blah blah 2","clicl on anyone",JOptionPane.DEFAULT_OPTION,JOptionPane.INFORMATION_MESSAGE,null,options,options[0]);
	System.out.println(x);
}
}