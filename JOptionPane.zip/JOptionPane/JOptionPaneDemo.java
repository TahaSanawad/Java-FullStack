import javax.swing.JOptionPane;
public class JOptionPaneDemo
{
	public static void main(String[] args)
{
	
	String input = JOptionPane.showInputDialog("blah blah blah");
	System.out.println("the input by user is: "+ input);
	
}
}