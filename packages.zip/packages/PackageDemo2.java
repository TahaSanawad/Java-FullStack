import mypackage2.*;

public class PackageDemo2
{
	public static void main(String[] args )
	{
		Animal ob=new Animal();// the stateent are accessing the Animal class
		ob.eat();
		Bird ob2=new Bird();
		ob2.fly();
	}

} 