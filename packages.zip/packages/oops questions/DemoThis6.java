class DemoThis6{  
	DemoThis6 m1()
	{
		return this;// we r not getting error it means this is returning something and that something is instance of current class
	}
	public static void main(String[] args){
		DemoThis6 a= new DemoThis6();
		a.m1();
	}
}