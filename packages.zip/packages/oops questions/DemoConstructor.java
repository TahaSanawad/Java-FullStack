class DemoConstructor
{
	public DemoConstructor()
	{
		int i;
		String s;
		System.out.println("Default constructor");
	}
	public Static void main(String[] args)
	{
	 DemoConstructor t=new DemoConstructor();
	 System.out.println(t.i + "  " + t.s);// return default value of int and string
	}

}