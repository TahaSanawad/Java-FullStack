class A{  
	A(){
		System.out.println("hello a");
	}  
	A(int x){  
		this();  //invoking current class constructor
		System.out.println(x);  
	}  
}  
class DemoThis3{  
public static void main(String args[]){  
A a=new A(10);  
}}  