class A{  
	void m1(){
	System.out.println("hello m1");
	}  
	void m2(){  
	System.out.println("hello m2");  
	
				// this.m1()  is invoking current class method
				//  if we write m1() the output is same cs this is used implicitly
	this.m1();  
	}  
	}  
class DemoThis2{  
public static void main(String args[]){  
A a=new A();  
a.m2();  
}
}  