class 	DemoThis4{  
  void m(DemoThis4 obj){  
  System.out.println("method is invoked");  
  }  
  void p(){  
  m(this);  
  }  
  public static void main(String args[]){  
  DemoThis4 s1 = new DemoThis4();  
  s1.p();  
  }  
}  