abstract class Vehicle
{
	abstract void start();
}
class Car extends Vehicle
{
	void start()
	{
		System.out.println("start by key or button");
	}
}
class Bike extends Vehicle{
	void start()
	{
		System.out.println("starts with kick");
	}
	public static void main(String[] args){
		//Vehicle v = new Vehicle();
		Car c = new Car();
		c.start();
		Bike b=new Bike();
		b.start();
	
	}
}