class MethodLoad5
{
	public static void main(String[] args)
	{
		System.out.println("yash");
		MethodLoad5 obj=new MethodLoad5();
		obj.main(10);
	}
	public static void main(int a)
	{
		System.out.println("tecnologies");
	}
	//no error hence main method can be overloaded

		


}