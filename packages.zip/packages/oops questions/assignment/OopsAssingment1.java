class OopsAssingment1
{
	double h,w,d;
	
	
	OopsAssingment1(double height, double width, double depth)
	{
	h = height;
	w = width;
	d = depth;
	}
	
	double volumeOfBox()
	{
	double v = h*w*d;
	return v;
	}
	
	public static void main(String[] args)
	{
	OopsAssingment1 a = new OopsAssingment1(5,5.5,6);
	System.out.println(a.volumeOfBox());
	}
	


}