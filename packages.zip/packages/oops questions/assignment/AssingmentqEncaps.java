class Author{
	protected String name,email;
	protected char gender;
	public Author (String name,String email,char gender)
	{
		super();
		this.name=name;
		this.email=email;
		this.gender=gender;
	}
	public String getName()
	{
		return name;
	
	}
	public String getEmail()
	{
		return email;
	
	}
	public char getGender()
	{
		return gender;
	}

	public String toString()
	{
	return "   \n [name=" + name + "  email=" + email +"  gender= "+ gender + "]\n";
	}	
}
 
 
class Book{
	private String name;
	private Author author;
	private double price;
	private int qtylnStock;
	
	public Book(String name,Author author, double price, int qtylnStock )
	{
	super();
	this.name=name;
	this.author=author;
	this.price=price;
	this.qtylnStock=qtylnStock;
	}
	public double getPrice()
	{
		return price;
	}
	public void setPrice(double price){
		this.price=price;
	}
	public int getQtylnstock(){
		return qtylnStock;
	}
	public void setQtylnstock(int qtylnStock){
		this.qtylnStock=qtylnStock;
	}
	public String getName(){
		return name;
	}
	public Author getAuthor(){
		return author;
	}
	public String toString(){
		return "BOOK[name="+ name + ",author=" + author + ",price="+ price+",qtylnStock=" + qtylnStock + "]";
	
	}
	
}
public class  AssingmentqEncaps{
	public static void main(String[] args){
	
	Author author = new Author("Taha Sanawad","Taha.sanawad@yash.com",'M');
	//System.out.println(author.theString());
	Book book = new Book("how not to get a job",author,1.99,500);
	System.out.println(book.toString());
	}


}

	
	