class Patient
{
 String name;
 double weight,height;
 Patient(String n, double w, double h)
 {
 name=n;
 weight=w;
 height=h;
 }
 void BMI()
 {
 double bmi=(weight/(height*height));
 System.out.println("your BMI is " + bmi);
 }
}
class OopsAssingment2
{
public static void main(String[] args){
Patient p1=new Patient("yash",2.0,3.0);
p1.BMI();

}
}