class Employee
{
	private int emp_id;//data hiding
	public void setEmpid(int emp_id)
	{
		this.emp_id = emp_id ;// or we can write this.emp_id=emp_id
	}
	public int getEmpId()
	{
		return emp_id;
	}

}
class Encapsulation
{
	public static void main(String[] args)
	{
	Employee e = new Employee();
	e.setEmpid(10000);
	System.out.println(e.getEmpId());
	
	}


}