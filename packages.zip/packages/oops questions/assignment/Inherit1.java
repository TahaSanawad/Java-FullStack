class Animal{
	public void eat()
	{
		System.out.println("eat ANIMAL");
	}
	public void sleep()
	{
		System.out.println("sleep 	ANIMAL");
	}
}
class Bird extends Animal{
	public void eat()
	{
		System.out.println("BIRD eat");
		
	}
	public void sleep()
	{
		System.out.println("BIRD sleep ");
	}
	public void fly()
	{
		System.out.println("Bird fly");
	}
}
	
class Inherit1{
	public static void main(String[] args){
		Animal a= new Animal();
	Bird b = new Bird();
	a.eat();
	a.sleep();
	b.fly();
	b.eat();
	b.sleep();




	}
}