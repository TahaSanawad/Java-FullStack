class AnimalMethod
{
	String color;
	int age;
	void initObject(String c,int a)
	{
		color=class;
		age=a;
	
	}
	void display()
	{
		 System.out.println(color+" "+age);
	}
	public static void main(String[] args);
	(
		AnimalMethod sheru=new AnimalMethod();
		sheru.initObject("Black",20);
		sheru.display();

	)




}