class TypePro3
{
	void display(StringBuffer a)
	{
		System.out.println("StringBuffer");
	}
	void display(String a)
	{
		System.out.println("String");
	}
	public static void main(String[] args)
	{
	TypePro3 t=new TypePro3();
	t.display("www");
	t.display(new StringBuffer("JAJAJ"));
	}
	
}