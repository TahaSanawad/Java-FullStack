abstract class Animal
{
	abstract void eat();
}
class Cat extends Animal
{
	void eat()
	{
		System.out.println("cat is eating");
	}
}
class Dog extends Animal{
	void eat()
	{
		System.out.println("dog is eating");
	}
	public static void main(String[] args){
		//Animal a = new Animal();
		Cat c = new Cat();
		c.eat();
		Dog d=new Dog();
		d.eat();
	
	}
}