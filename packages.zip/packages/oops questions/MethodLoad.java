class MethodLoad
{ // same name number of arguments is different
	void show(int a,int b){
		System.out.println("yash");
	}
	void show()
	{
	System.out.println("Technolgies");
	}
	public static void main(String[] args)
	{
	MethodLoad A= new MethodLoad();
	A.show();
	A.show(10,20);
	}
} 