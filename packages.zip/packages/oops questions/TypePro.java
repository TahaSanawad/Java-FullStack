class TypePro
{
void show(int a)
	{
		System.out.println("YASH");
	}
void show(String b)
	{
		System.out.println("String Method");
	}
	public static void main(String[] args)
	{
	 TypePro t=new TypePro();
	 t.show('j');
	 //here we are passing char and it is being pramoted to int so our output will be= YASH
	}
}