class MethodLoad4
{	//can we overload using changing return type of method only
	void show(int a)
	{
		System.out.println("yash");
	}
	String show(int a)
	{
	System.out.println("Technolgies");
	}
	public static void main(String[] args)
	{
	MethodLoad4 A= new MethodLoad4();
	
	A.show(10);//ambiguity is there
	// no we cant overload
	}
}