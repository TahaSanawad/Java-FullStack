abstract class A 
{
 public abstract void run();
 {
 System.out.println("run in class A");
 }
}
class AnnonymousClass2{
	 public static void main(String[] args) {
	 A obj =new A()
		{
			public void run(){
			System.out.println("run in Annonymousclass ");
			}
		
		};
		obj.run();
}
}