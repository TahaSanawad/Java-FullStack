class A
{
	void displayA()
	{
		System.out.println("A Class");
	}

}
class B extends A
{
	void displayB()
	{
		System.out.println("B Class");
	}

}
class C2 extends A
{
	void displayC()
	{
		System.out.println("C Class");
	}
	public static void main(String[] args)
	{
	A ob1=new A();
	ob1.displayA();
	//ob1.displayB(); error as A class do not inherit B class
	B ob2=new C();
	ob2.displayA();
	ob2.displayB();
	//ob2.displayC(); error as B class do not inherit C class
	
	C ob3 = new C();
	ob3.displayA();
	//ob3.displayB(); error as C class  do not inherit B class 
	ob3.displayC();
	
	
	}

}
