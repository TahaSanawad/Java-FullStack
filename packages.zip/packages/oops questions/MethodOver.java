class A{
	public int a(){
		return 2;
		}
	public void b(){
		System.out.println("method b OF CLASS A");
	}
	}
class B extends A
{   
	public void b(){
		System.out.println("method b of class B");
	}
	public void c(){
		System.out.println("mthod c of class B");
	}
} 
class MethodOver
{
	public static void main(String[] args){
	A a=new A();
	a.b();
	B b=new B();
	b.b();
	}
}
/*can we have different return typr while overrding 
befor jdk 5 it is not possibe to override while having different return type
it is possible for different return type in child class but child return type
should be shoud be sub type of parets return type overrdingmethod becomes varient with return type so this is called
 covarient return type*/