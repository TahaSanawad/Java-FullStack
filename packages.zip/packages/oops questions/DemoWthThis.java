class Demo
{
	int i;//instance variable
	void setValue(int i)//local variable 
	{
		//i=i;here i will have value = 0
		this.i = i; //here i will have value = 15
	}
	void show()
	{
		System.out.println(i);
	}

	
}
class DemoWthThis
{
public static void main(String[] args)
 {
	Demo d = new Demo();
	d.setValue(15);
	d.show();
 }

}