class ClassCast2
{
public static void main()
{
 int i = 43;
 String s = (String)i;//ClassCast2.java:6: error: incompatible types: int cannot be converted to String String s = (String)i;
}
}