class MethodLoad3
{	//same name types of arguments is different
	void show(int a)
	{
		System.out.println("yash");
	}
	void show(String a)
	{
	System.out.println("Technolgies");
	}
	public static void main(String[] args)
	{
	MethodLoad3 A= new MethodLoad3();
	A.show(10);
	A.show("lkl");
	}
}