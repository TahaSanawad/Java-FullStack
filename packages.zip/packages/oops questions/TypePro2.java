class TypePro2
{
void show(Object a)
	{
		System.out.println("YASH");
	}
void show(String b)
	{
		System.out.println("String Method");
	}
	public static void main(String[] args)
	{
	 TypePro t=new TypePro();
	 t.show('k');
	 //here we are passing char and ouput will be YASH
	}
}