class MethodLoad2
{	//same name sequence of arguments is different
	void show(int a,String b)
	{
		System.out.println("yash");
	}
	void show(String a, int b)
	{
	System.out.println("Technolgies");
	}
	public static void main(String[] args)
	{
	MethodLoad2 A= new MethodLoad2();
	A.show("kk",10);
	}
}