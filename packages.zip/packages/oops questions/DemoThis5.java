class B{  
  DemoThis5 obj;  
  B(DemoThis5 obj){  
    this.obj=obj;  
  }  
  void display(){  
    System.out.println(obj.data);//using data member of DemoThis5 class  
  }  
}  
  
class DemoThis5{  
  int data=10;  
  DemoThis5(){  
   B b=new B(this);  
   b.display();  
  }  
  public static void main(String args[]){  
   DemoThis5 a=new DemoThis5();  
  }  
}  