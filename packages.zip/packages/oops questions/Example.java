class Example
{
	Example()
	{
		this(3,3);
		System.out.println("Default constructor");
	}
	
	Example(int i, int j)
	{
		
		System.out.println("parametrized constructor with two argumens");
	}
	
	
	public static void main(String[] args)
	{
		Example onb1=new Example();
		//Example onb2=new Example(12,12);
	}
	
}
