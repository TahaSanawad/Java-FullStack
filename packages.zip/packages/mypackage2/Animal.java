package mypackage2;
public class Animal
{
	public void eat()
	{
			System.out.println("I am in eat-Animal class");
	}
}