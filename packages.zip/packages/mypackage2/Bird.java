package mypackage2;
public class Bird
{
	public void fly()
	{
			System.out.println("I am in fly-Bird class");
	}

}