import mypackage.Start;
class PackageDemo
{
	public static void main(String[] args )
	{
		mypackage.Start ob = new mypackage.Start();
		//Start ob=new Start(); both the stateent are accessing the start class
		ob.display();
	}

} 