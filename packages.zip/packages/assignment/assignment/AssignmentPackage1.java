import testpackage.Foundation;
class AssignmentPackage1{
	public static void main(String [] args){
	Foundation a= new Foundation();
		//System.out.println(a.var1); error: var1 has private access in Foundation
        //System.out.println(a.var2);  var2 is not public in Foundation; cannot be accessed from outside package
        //System.out.println(a.var3); error: var3 has protected access in Foundation
        System.out.println(a.var4); // 0 as default value of int is zero
	}


}