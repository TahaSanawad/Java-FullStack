class Assingment6
{
	public static void main(String[] args)
	{
	// swap two numbers without 3rd variable
		int a= Integer.parseInt(args[0]);
		int b= Integer.parseInt(args[1]);
	
		System.out.println("user entered a=" +a+ " user entered b=" + b);
		a=a+b;
		b=a-b;
		a=a-b;
		System.out.println("after swap a="+ a +" after swap b=" + b);
		

	}
}