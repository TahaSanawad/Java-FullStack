class Assingment2
{
	public static void main(String[] args)
	{
	// even or odd
		int a= Integer.parseInt(args[0]);
	
		
		if (a%2==0)
		System.out.println("a is even");
		
		else 
		System.out.println("a is odd");
		

	}
}