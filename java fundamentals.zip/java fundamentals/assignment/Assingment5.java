class Assingment5
{
	public static void main(String[] args)
	{
	// swap two numbers
		int a= Integer.parseInt(args[0]);
		int b= Integer.parseInt(args[1]);
	
		System.out.println("user entered a=" +a+ " user entered b =" + b);
		int c = a;
		a=b;
		b=c;
		System.out.println("after swap a="+ a +" after swap b=" + b);
		

	}
}