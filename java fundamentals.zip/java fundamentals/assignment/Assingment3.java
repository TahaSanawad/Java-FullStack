class Assingment3
{
	public static void main(String[] args)
	{
	// Find leap year
		int a= Integer.parseInt(args[0]);
	
		
		if (a%400==0)
		System.out.println(a + " is leap year");
		else if (a%100==0)
		System.out.println(a + " is not a leap year");
		else if (a%4==0)
		System.out.println(a + " is leap year");
		else
		System.out.println(a + " is not leap year");

	}
}