class Assingment4
{
	public static void main(String[] args)
	{
	// calculator
		int a= Integer.parseInt(args[0]);
		int b= Integer.parseInt(args[1]);
		char operater= args[2].charAt(0);
		int result;
		switch(operater){
		case '+':
			result = a + b;
			System.out.println("sum is=" + result);
			break;
		case '-':
			result = a - b;
			System.out.println("sum is=" + result);
			break;
		case '/':
			result = a / b;
			System.out.println("sum is=" + result);
			break;
		case '*':
			result = a * b;
			System.out.println("multiplication is=" + result);
			break;
		}
			
	}
}
		
	
		
		
		

	