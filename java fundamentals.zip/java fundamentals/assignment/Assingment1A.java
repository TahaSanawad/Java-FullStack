class Assingment1A
{
	public static void main(String[] args)
	{
	//find langest of two number
		int a= Integer.parseInt(args[0]);
		int b= Integer.parseInt(args[1]);
		if (a>b)
		System.out.println("a is largest");
		
		else if (b>a)
		System.out.println("b is largest");
		
		else
		System.out.println("a and b is equal");

	}
}