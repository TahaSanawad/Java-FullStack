class AssingmentLoop11
{
	public static void main(String[] args)
	{
	//star pattern
/*  *
	**
	***
	****
	***
	**
	*    */
		int number= Integer.parseInt(args[0]);
		for(int i=0;i<number;i++){
			for(int j=0;j<=i;j++)
		{
				System.out.print("*");
		}
		System.out.println();
		}
		
		
		for(int i=0;i<number;i++){
			for(int j=i+1;j<number;j++)
		{
				System.out.print("*");
		}

		System.out.println();
		}
		
		

	}
}