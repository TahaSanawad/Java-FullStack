class AssingmentLoop8
{
	public static void main(String[] args)
	{
	//febbonaci series
		int a= Integer.parseInt(args[0]);
		int r,sum=0,temp;
		temp=a;
		while(a>0){
		r=a%10;
		sum=(sum*10)+r;
		a=a/10;
		}
		if(temp==sum)
		System.out.println(temp + " is palindrome");
		else
		System.out.println(temp + " is not palindrome");
		

	}
}