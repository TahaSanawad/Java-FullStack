class AssingmentLoop1
{
	public static void main(String[] args)
	{
	//print table
		int a= Integer.parseInt(args[0]);
		int result=0;
		for(int i=1;i<=10;i++){
		result=a*i;
		System.out.println(a + " * " + i + " = " + result);
		}
	}
}