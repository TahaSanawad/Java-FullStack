class AssingmentLoop2
{
	public static void main(String[] args)
	{
	//print Factorial
		int a= Integer.parseInt(args[0]);
		int result=1;
		for(int i=a;i>=1;i--){
		result= result* i;
		}
		System.out.println("factorial is =" + result);
	}
}