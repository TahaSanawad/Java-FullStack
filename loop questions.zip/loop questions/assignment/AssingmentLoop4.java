class AssingmentLoop4
{
	public static void main(String[] args)
	{
	//reverse a number
		int a= Integer.parseInt(args[0]);
		int remainder;
		int result=0;
		while(a!=0){
		
		remainder = a % 10;
		result=result*10 + remainder;
		a=a/10;
		
		}
		System.out.println("reversed number is =" + result);
	}
}