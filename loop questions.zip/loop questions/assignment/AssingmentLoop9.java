class AssingmentLoop9
{
	public static void main(String[] args)
	{
	//armstrong
		int number= Integer.parseInt(args[0]);
		int onum,r,result=0;
		onum=number;
		while(onum>0)
		{
		r=onum%10;
		result = result + (r*r*r);
		onum=onum/10;
		}
		if (result==number){
		System.out.println(number + " is armstrong");
		}
		else
		System.out.println(number+ " is not armstrong");
		
		

	}
}