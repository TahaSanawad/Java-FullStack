class AssingmentLoop6
{
	
	static boolean isPrime(int a)
	{
	if (a<=1)
		return 	false;
	
	for(int i = 2; i<a;i++)
		if (a%i==0)
		return false;
	return true;
	}
	static void sumPrime(int a)
	{
	int result=0;
	for(int i = 2;i<=a;i++)
	{
		if (isPrime(i))
			result =result+i;
	}
	System.out.println(result);
	}
	public static void main(String[] args)
	{
	//prime numder
		int result=0;
		int a= Integer.parseInt(args[0]);
		sumPrime(a);
	}
		
}