class AssingmentLoop5
{
	public static void main(String[] args)
	{
	//prime numder
		int result=0;
		int a= Integer.parseInt(args[0]);
		
		
		for(int i=2;i<=a;i++){
		if (a%i==0){
		System.out.println(" number is not prime");
		result=1;
		break;}
		}
		if(result==0)
		System.out.println(" number is prime");
		
		
	}
}