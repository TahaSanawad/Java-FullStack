class AssingmentLoop13
{
	public static void main(String[] args)
	{
	/*number pattern
1
23
456
78910
	*/
		int number= Integer.parseInt(args[0]);
		int count=0;
		for(int i=0;i<number;i++){
			for(int j=0;j<=i;j++)
		{
				count = count+1;
				System.out.print(count + " ");
		}
		System.out.println();
		}
	
		
		

	}
}