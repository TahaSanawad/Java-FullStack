class StringAssingment9
{
	 public static void main(String[] args)
	 {
		String OS;
		OS=args[0];
		int n = OS.length();
		if(n%2==0)
			System.out.println("String length is even:"+ n + "and half of given string:" + OS +" is=" + OS.substring(0,n/2));
		else
			System.out.println("null");
		
		 
	} 
} 