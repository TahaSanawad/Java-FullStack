class StringAssingment11
{
	 public static void main(String[] args)
	 {
		StringBuilder s1 = new StringBuilder("Yash Technologirs");
		System.out.println(s1.isEmpty());
		// error as there is no isempty method sor stringbuilder
		 
	} 
} 