class StringAssingment12
{
	 public static void main(String[] args)
	 {
		StringBuilder s1 = new StringBuilder("  Yash Technologirs");
		System.out.println("string before trim function:" + s1);
		
		System.out.println("after trim:"+ s1.trim());
		
		 
	} 
} 