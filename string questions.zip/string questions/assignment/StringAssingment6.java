class StringAssingment6
{
	 public static void main(String[] args)
	 {
		String s1 = "Yash Technologies";
		String s2 = "YASH TECHNOLOGIES";
		String s3 = "hello";
		String s4 = "HEMLO";
	
		System.out.println("s1="+ s1 + "  s2=" + s2 + " s1.compareToIgnoreCase(s2)" + s1.compareToIgnoreCase(s2)); //both same thats why 0
		System.out.println("s3="+ s3 + "  s4=" + s4 + " s3.compareToIgnoreCase(s4)" + s3.compareToIgnoreCase(s4)); //l-m == -1
		
		 
	} 
} 