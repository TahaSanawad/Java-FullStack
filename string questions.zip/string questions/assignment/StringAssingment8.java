class StringAssingment8
{
	 public static void main(String[] args)
	{
		String 	OS,RS="";
		OS=args[0];
		int length = OS.length();
		for(int i=length-1;i>=0;i--)
			RS=RS+	OS.charAt(i);
		if(OS.equals(RS))
			System.out.println("entered string = "+ OS +" is palindrome");
		else
			System.out.println("entered string = "+ OS +" is not palindrome");
		 
	} 
} 