class StringAssingment4
{
	 public static void main(String[] args)
	 {
		String s1 = "Yash Technologies";
		String s2 = "YASH TECHNOLOGIES";
		
		System.out.println("s1="+ s1 + "  s2=" + s2 + " equalsIgnoreCase=" + s1.equalsIgnoreCase(s2));
		
		 
	} 
} 