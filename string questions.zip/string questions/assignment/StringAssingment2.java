class StringAssingment2
{
	 public static void main(String[] args)
	 {
		String s1 = "  Yash Technologirs";
		System.out.println("string before trim function:" + s1);
		
		System.out.println("after trim:"+ s1.trim());
		
		 
	} 
} 