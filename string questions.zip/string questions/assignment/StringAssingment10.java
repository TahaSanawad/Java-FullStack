class StringAssingment10
{
	 public static void main(String[] args)
	 {
		String OS,RS="";
		OS=args[0];

		int length = OS.length();
		
		System.out.println("entered text:" + OS);
		for(int i=1;i<=length-2;i++){
			RS = RS + OS.charAt(i);
			//System.out.println(RS);
		}
		if(length>2){
			System.out.println("after exclusion of 1 and last CHAR:" +  RS	);
		}
		else{
			System.out.println("enter a igger string");
		}
			
		
		 
	} 
} 