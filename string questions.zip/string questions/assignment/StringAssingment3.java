class StringAssingment3
{
	 public static void main(String[] args)
	 {
		String s1 = "  Yash Technologirs";
		String s2 = "  Yash Technologirs";
		System.out.println(s1.equals(s2));
		
		 
	} 
} 