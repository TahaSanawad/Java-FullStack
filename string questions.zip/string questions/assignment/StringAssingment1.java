class StringAssingment1
{
	 public static void main(String[] args)
	 {
		String s1 = "Yash Technologirs";
		System.out.println(s1.isEmpty());
		
		 
	} 
} 