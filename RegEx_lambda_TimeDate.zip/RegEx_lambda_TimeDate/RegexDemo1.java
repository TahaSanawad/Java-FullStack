import java.util.regex.*;
public class RegexDemo1{
	public static void main(String[] args){
	Pattern p = Pattern.compile("\\d+");
	Matcher m = p.matcher("kjjhdueewy63t6464ygyegy4y474");
	while(m.find()){
	System.out.println(m.group());
	}
	}
}