import java.util.regex.*;
public class RegexDemo3{
	public static void main(String[] args){
	String s="ahahahhahah'substring'lalalla";
	Pattern p=Pattern.compile("'(.*?)'");
	Matcher m = p.matcher(s);
	if (m.find())
	{
	 System.out.println(m.group(1));
	}
	}
	}