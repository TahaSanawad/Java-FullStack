interface DemoAno{
    void meth1();
}
/*class LamFunc implements DemoAno{
    public void meth1(){
        System.out.println("i am in meth1");
    }
}*/
public class LambdaDemo {
    public static void main(String[] args){
    /*DemoAno obj = new LamFunc();
    obj.meth1();*/
    DemoAno obj=()->{
        System.out.println("i am meth 1 in lambda expression");
        };   
    obj.meth1();
    }
    
}
