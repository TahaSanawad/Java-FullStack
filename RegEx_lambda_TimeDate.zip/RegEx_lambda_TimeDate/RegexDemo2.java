
public class RegexDemo2{
	public static void main(String[] args){
	String s="lslsls\najskkka\naalla";
	String[] str=s.split("\n");
	System.out.println(s);
	for(int i =0;i<str.length;i++){
	System.out.print(str[i]);
	}
	}
	}
	