import java.io.*;
class SequenceInputDemo
{
	public static void main(String [] args)throws Exception
	{
	FileInputStream f1=new FileInputStream("d:/abc.txt");
	FileInputStream f2=new FileInputStream("d:/xyz.txt");
	
	SequenceInputStream st=new SequenceInputStream(f1,f2);
	
	FileOutputStream out = new FileOutputStream("d:/abcd.txt");
	int i;
	while((i=st.read())!=-1)
		out.write(i);
		System.out.print((char)i);
	
	st.close();
	f1.close();
	f2.close();
	}


}

















