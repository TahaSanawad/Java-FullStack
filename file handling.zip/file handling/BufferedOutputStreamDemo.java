import java.io.FileOutputStream;
import java.io.BufferedOutputStream;
class BufferedOutputStreamDemo{
public static void main(String [] args) throws Exception{
FileOutputStream f=new FileOutputStream("d:/outputdemo.txt");
BufferedOutputStream b = new BufferedOutputStream(f);
String s="get well soon sir!!";
byte b1[]=s.getBytes();
b.write(b1);
b.close();
f.close();
}
}