import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
class FileInputOutputStreamDemo
{
	public static void main(String [] args) throws IOException
	{
		FileInputStream in = new FileInputStream("d:/abc.txt");
		FileOutputStream out = new FileOutputStream("d:/xyz.txt");
		int c;
		while((c=in.read())!=-1){
			out.write(c);
		System.out.println((char)c);}
		in.close();
		out.close();
		
	}
}