import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
class FileReaderWriter{
	public static void main(String[] args) throws IOException{
		File f = new File("d:/readwrite.txt");
		f.createNewFile();
		FileWriter w=new FileWriter(f);
		w.write("welcome to yash ");
		w.close();
		FileReader r = new FileReader(f);
		char[] a=new char[20];
		r.read(a);//read and store
		for(char c:a)
			System.out.println(c);
	r.close();}
}