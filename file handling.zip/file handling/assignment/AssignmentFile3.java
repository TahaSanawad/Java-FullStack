import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;
class AssignmentFile3
{
	public static void main(String [] args)  throws IOException
	{
	FileInputStream in=null;
	int a=0;
	Scanner sc = new Scanner(System.in);
	System.out.println("enter the character: ");
	char chr= sc.next().charAt(0);
	try{
		 in = new FileInputStream("d:/yash.txt");
		
		int c;
		while((c=in.read())!=-1){
			if (((char) c)==chr){
				a+=1;
			}
		}
	}
	finally{
		System.out.println(a);
		
		if(in!=null)
			in.close();

	}	
	}
}