import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
class AssignmentFile2
{
	public static void main(String [] args)  throws IOException
	{
	FileInputStream in=null;
	int a=0,e=0,i=0,o=0,u=0;
	
	try{
		 in = new FileInputStream("d:/yash.txt");
		
		int c;
		while((c=in.read())!=-1){
			if (((char) c)=='a'){
				a+=1;
			}
			else if (((char) c)=='e' ){
				e+=1;
			}
			else if (((char) c)=='i'){
				i+=1;
			}
			else if (((char) c)=='o'){
				o+=1;
			}
			else if (((char) c)=='u'){
				i+=1;
			}
		}
	}
	finally{
		int sum=a+e+i+o+u;
		System.out.println("total vowels "+ sum);
		System.out.println("total a "+a);
		System.out.println("total e "+e);
		System.out.println("total i "+i);
		System.out.println("total o "+o);
		System.out.println("total u "+u);
		if(in!=null)
			in.close();

	}	
	}
}