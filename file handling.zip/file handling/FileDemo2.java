import java.io.File;
import java.io.IOException;
class FileDemo2
{
public static void main(String [] args) throws IOException
{
	File f=new File("d:/abc.txt");
	f.createNewFile();//for creating new file
	System.out.println(f.exists());// check existing or not
	System.out.println(f.canWrite());// can we write
	System.out.println(f.getName());//get name of file
	System.out.println(f.length());//size
	f.delete();// delete the file
}

}