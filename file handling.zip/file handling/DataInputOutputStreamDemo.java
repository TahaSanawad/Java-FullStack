import java.io.*;
public class DataInputOutputStreamDemo{
	public static void main(String[] args) throws IOException{
		try
		{ 
			File obj=new File("d:/dataInputoutput.txt");
			FileOutputStream fout=new FileOutputStream(obj);
			DataOutputStream dout =new DataOutputStream(fout);
			dout.writeInt(343);
			dout.writeUTF("Get well soon sir");
			dout.writeBoolean(true);
			fout.close();
			dout.close();
			
			FileInputStream fin=new FileInputStream(obj);
			DataInputStream din=new DataInputStream(fin);
			int data=din.readInt();
			String str=din.readUTF();
			boolean result=din.readBoolean();
			System.out.println(data);
			System.out.println(str);
			System.out.println(result);
			din.close();
			fin.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
			
		}
			
			
	
	}

}