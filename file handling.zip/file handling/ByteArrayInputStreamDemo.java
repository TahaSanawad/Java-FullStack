import java.io.*;
public class ByteArrayInputStreamDemo{
	public static void main(String[] args) throws Exception{
		byte data[]="yash technologies ByteArrayInputStreamDemo".getBytes();
		ByteArrayInputStream is=new ByteArrayInputStream(data);
		is.read(data);
		File f=new File("d:/bytearraydemo.txt");
		FileOutputStream fout=new FileOutputStream(f);
		fout.write(data);
	}


}