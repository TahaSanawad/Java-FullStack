package com.spring.jdbcProject.dao;

import com.spring.jdbcProject.entities.Employee;
import org.springframework.jdbc.core.JdbcTemplate;

public class EmployeeDaoImpl implements EmployeeDao{
	private JdbcTemplate jdbcTemplate;
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public int insert(Employee employee) {
		// TODO Auto-generated method stub
		String query="insert into employee values(?,?,?,?,?,?)";
	    int id=employee.getId();
	    int r=this.jdbcTemplate.update(query,id,employee.getEmpname(),employee.getEmailid(),employee.getDob(),employee.getContactno(),employee.getSalary());
	    return r;
	}

	public int change(Employee employee) {
		String query="update employee set empname=?,emailid=?,dob=?,contactno=?,salary=? where id=?";
		int r=this.jdbcTemplate.update(query,employee.getEmpname(),employee.getEmailid(),employee.getDob(),employee.getContactno(),employee.getSalary(),employee.getId());
		return r;
	}

	public int delete(int employeeID) {
		// TODO Auto-generated method stub
		String query="delete from employee where id=?";
		int r=this.jdbcTemplate.update(query,employeeID);
		return r;
	}

}
