package com.spring.jdbcProject;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.jdbcProject.dao.EmployeeDao;
import com.spring.jdbcProject.entities.Employee;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("com/spring/jdbcProject/config.xml");
		context.getBean("employeeDao", EmployeeDao.class);
		EmployeeDao employeeDao = context.getBean("employeeDao", EmployeeDao.class);
		Employee employee = new Employee();
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter Admin name: ");
		String admin_name = sc.nextLine();
		System.out.print("Enter Admin PASSWORD: ");
		String admin_password = sc.nextLine();
		if (admin_name.equals("Taha") && admin_password.equals("12345")) {
			int n = 1;
			while (n != 0) {
				System.out.println("For adding an employee press 1");
				System.out.println("For editing  an employee detail press 2");
				System.out.println("For deleting  an employee detail press 3");
				System.out.println("press 5 to exitttt....!!");
				String input_user = sc.next();
				if (input_user.equals("1")) {
					System.out.println("enter Employee ID");
					int id = sc.nextInt();
					employee.setId(id);
					System.out.println("enter employee name");
					String name = sc.next();
					employee.setEmpname(name);
					System.out.println("enter employee contact number");
					int num = sc.nextInt();
					employee.setContactno(num);
					System.out.println("Enter dob in YYYY-MM-DD formate");
					String dat = sc.next();
					employee.setDob(dat);
					System.out.println("enter salary");
					int sal = sc.nextInt();
					employee.setSalary(sal);
					System.out.println("enter email");
					String email = sc.next();
					employee.setEmailid(email);
					int result = employeeDao.insert(employee);
					System.out.println("student added..." + result);
				}
				if (input_user.equals("2")){
					System.out.println("enter Employee ID");
					int id = sc.nextInt();
					employee.setId(id);
					System.out.println("enter employee name");
					String name = sc.next();
					employee.setEmpname(name);
					System.out.println("enter employee contact number");
					int num = sc.nextInt();
					employee.setContactno(num);
					System.out.println("Enter dob in YYYY-MM-DD formate");
					String dat = sc.next();
					employee.setDob(dat);
					System.out.println("enter salary");
					int sal = sc.nextInt();
					employee.setSalary(sal);
					System.out.println("enter email");
					String email = sc.next();
					employee.setEmailid(email);
					int result = employeeDao.change(employee);
					System.out.println("employee changed succesfully..." + result);
				}
				if (input_user.equals("3")){
					System.out.println("enter Employee ID");
					int id = sc.nextInt();
					int result=employeeDao.delete(id);
					System.out.println("data Deleted..." + result);
				}
				if (input_user.equals("5")){
					break;
				}
				
			}
		} else {
			System.out.println("wrong ADMIN username or password");
		}
	}
}
