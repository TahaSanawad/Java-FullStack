package com.practice;

public class LoginData {

}
