package com.practice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringvalidationApplicationTests {

	@Test
	void contextLoads() {
	}

}
