package com.spring.springorm;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.spring.springorm.dao.StudentDao;
import com.spring.springorm.entities.Student;

public class App {
	public static void main(String[] args) {
		System.out.println("Hello World!");
		ApplicationContext context = new ClassPathXmlApplicationContext("config.xml");
		StudentDao studao = context.getBean("studentDao", StudentDao.class);
//		Student stu = new Student(4, "Jass");
//		int msg = studao.insert(stu);
//		System.out.println(msg + "insertion done");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int n = 1;
		while (n == 1) {
			System.out.println("press 1 to add new student");
			System.out.println("press 2 tp display all student");
			System.out.println("press 3 to get deatail of single student");
			System.out.println("press 4 to for delete student");
			System.out.println("press 5 for update student");
			System.out.println("press 6 for exit");
			try {
				int input = Integer.parseInt(br.readLine());
				switch (input) {
				case 1:
					System.out.println("Enter user id:");
					int uid = Integer.parseInt(br.readLine());
					System.out.println("Enter user Name:");
					String uName = br.readLine();
					Student s=new Student();
					s.setId(uid);
					s.setName(uName);
					int r=studao.insert(s);
					System.out.println("Student added"+r);
					System.out.println("-----------------");
					break;
				case 2:
					//all student
					List<Student> allStudents=studao.getAllStudents();
					for(Student st:allStudents) {
						System.out.println("id: "+st.getId());
						System.out.println("name:"+st.getName());
						System.out.println("-----------------");
					}
					break;
				case 3:
					//single student
					//Student s1=new Student();
					System.out.println("Enter user id:");
					int uid2 = Integer.parseInt(br.readLine());
					Student student=studao.getStudentDetails(uid2);
					System.out.println("id: "+ student.getId());
					System.out.println("name:"+student.getName());
					System.out.println("-----------------");
					break;
				case 4:
					System.out.println("Enter user id:");
					int uid3 = Integer.parseInt(br.readLine());
					studao.deleteDetails(uid3);
					System.out.println("Student deleted");
					System.out.println("-----------------");
					break;
				case 5:
					System.out.println("Enter user id:");
					int uid4 = Integer.parseInt(br.readLine());
					System.out.println("Enter user Name:");
					String uName2 = br.readLine();
					Student s2=new Student();
					s2.setId(uid4);
					s2.setName(uName2);
					studao.updateDetails(s2);
					System.out.println("Student edited......");
					System.out.println("-----------------");
					break;
				case 6:
					n = 0;
					break;

				}
			} catch (Exception e) {
				System.out.println("Invalid input");
				e.printStackTrace();
			}
		}
	}
}