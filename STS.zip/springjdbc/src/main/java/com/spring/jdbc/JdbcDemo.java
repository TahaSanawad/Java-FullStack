package com.spring.jdbc;
import java.sql.*;
public class JdbcDemo {
	public static void main(String[] args)
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/myhiber";
			String user="root";
			String pass="root";
			Connection con=DriverManager.getConnection(url,user,pass);
			if(con!=null)
			{
				System.out.println("Connection is established");
			}
			else
			{
				System.out.println("Connection not established");
			}
			String query="Select * from employee";
			Statement st=con.createStatement();
			ResultSet set=st.executeQuery(query);
			while(set.next())
			{
				int id=set.getInt("id");
				String first_name=set.getString("first_name");
				String last_name=set.getString("last_name");
				int salary=set.getInt("salary");
				System.out.println("id: "+id);
			    System.out.println("first_name: "+first_name);
			    System.out.println("last_name: "+last_name);
			    System.out.println("salary: "+salary);
			}
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
