package com.spring.jdbc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import com.spring.jdbc.dao.StudentDao;
import com.spring.jdbc.entities.Student;

public class App {
	public static void main(String[] args) {
		System.out.println("Hello World!");
		ApplicationContext context = new ClassPathXmlApplicationContext("com/spring/jdbc/config.xml");
		context.getBean("studentDao", StudentDao.class);
		StudentDao studentDao = context.getBean("studentDao", StudentDao.class);
		//Student student = new Student();
		//insert
		/* update student.setId(3); student.setName("C"); student.setCity("Chennai");
		 * int result=studentDao.insert(student); System.out.println("student added..."+
		 * result);
		 */
		// change or update
		/*student.setId(3);
		student.setName("cc");
		student.setCity("chennnnnaiii");
		int result = studentDao.change(student);
		System.out.println("data changed..." + result);
		*/
		//delete
		/*int result=studentDao.delete(3);
		System.out.println("data Deleted..." + result);
		*/
		Student student =studentDao.getStudent(1);
		System.out.println(student);
		
		

	}
}
