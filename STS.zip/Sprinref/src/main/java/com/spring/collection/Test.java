package com.spring.collection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class Test {
public static void main(String[] args) {
	ApplicationContext context = new ClassPathXmlApplicationContext("applicationcontext.xml");
	Student p =(Student)context.getBean("student");
	System.out.println(p.getNamme());
	System.out.println(p.getPhones());
	System.out.println(p.getAddress());
	System.out.println(p.getCourses());
}
}
