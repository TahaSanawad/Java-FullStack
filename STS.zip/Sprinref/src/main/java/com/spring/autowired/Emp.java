package com.spring.autowired;

public class Emp {
private Address Address;

@Override
public String toString() {
	return "Emp [Address=" + Address + "]";
}

public Emp(com.spring.autowired.Address address) {
	super();
	Address = address;
}

public Emp() {
	super();
	// TODO Auto-generated constructor stub
}

public Address getAddress() {
	return Address;
}

public void setAddress(Address address) {
	Address = address;
}
}
