package com.spring.aware;

import org.springframework.context.ApplicationContextAware;

public class Demo implements ApplicationContextAware {
	

}
