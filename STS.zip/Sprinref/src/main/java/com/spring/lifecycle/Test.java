package com.spring.lifecycle;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
public class Test {
	public static void main(String[] args) {
		AbstractApplicationContext context=new ClassPathXmlApplicationContext("com/spring/lifecycle/applicationcontext.xml");
		context.registerShutdownHook();
		/*Food f1=(Food)context.getBean("jalebi");
		System.out.println(f1);
		context.registerShutdownHook();
		Coca c1=(Coca)context.getBean("coca");
		System.out.println(c1);*/
		Example e=(Example)context.getBean("example");
		System.out.println(e);
	}

}
