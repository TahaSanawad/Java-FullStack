package com.spring.eventhandling;

public class Person1 {
	private String name;
	private int personid;
	public Person1(String name,int personid) {
		this.name=name;
		this.personid=personid;
		
	}
	@Override
	public String toString() {
		return "Person [name=" + name + ", personid=" + personid + "]";
	}

}



