package com.spring.eventhandling;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.springcontructref.ci.Person;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = new ClassPathXmlApplicationContext("com/spring/eventhandling/applicationcontext.xml");
		Person1 P =(Person1)context.getBean("person");
		System.out.println(P);


	}

}
