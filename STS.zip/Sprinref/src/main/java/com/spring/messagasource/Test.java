package com.spring.messagasource;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
	public static void main(String[] args) {
		AbstractApplicationContext context=new ClassPathXmlApplicationContext("com/spring/messagasource/applicationcontext.xml");
		context.getMessage("greeting", null,"Default greting",null);
	}
		
}
