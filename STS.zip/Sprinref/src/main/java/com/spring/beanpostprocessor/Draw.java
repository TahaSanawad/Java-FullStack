package com.spring.beanpostprocessor;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Draw {
	public static void main(String[] args) {
	// TODO Auto-generated method stub
	ApplicationContext context = new ClassPathXmlApplicationContext("com/spring/beanpostprocessor/applicationcontext.xml");
	Triangle triangle=(Triangle)context.getBean("triangle");
	triangle.draw();
}
}
