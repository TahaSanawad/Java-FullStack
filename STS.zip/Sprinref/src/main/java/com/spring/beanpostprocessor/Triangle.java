package com.spring.beanpostprocessor;


public class Triangle {
	private Point pointA;
	private Point pointB;
	private Point poincC;
	public Triangle() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Point getPointA() {
		return pointA;
	}
	public void setPointA(Point pointA) {
		this.pointA = pointA;
	}
	public Point getPointB() {
		return pointB;
	}
	public void setPointB(Point pointB) {
		this.pointB = pointB;
	}
	public Point getPoincC() {
		return poincC;
	}
	public void setPoincC(Point poincC) {
		this.poincC = poincC;
	}
public void draw() {
	System.out.println("point A={"+getPointA().getX()+","+getPointA().getY()+"}");
	System.out.println("point B={"+getPointA().getX()+","+getPointA().getY()+"}");
	System.out.println("point C={"+getPointA().getX()+","+getPointA().getY()+"}");
	
}
	}
