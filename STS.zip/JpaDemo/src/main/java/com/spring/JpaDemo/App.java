package com.spring.JpaDemo;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {   Student s=new Student();
        System.out.println( "Hello World!" );
        EntityManagerFactory emf=Persistence.createEntityManagerFactory("pu");
        EntityManager em=emf.createEntityManager();
       // System.out.println(s);
        s.setId(8);
        s.setName("yashaa");
        s.setCity("haridwaaar");
        em.getTransaction().begin();
        em.persist(s);
        em.getTransaction().commit();
        System.out.println(s);
    }
}
