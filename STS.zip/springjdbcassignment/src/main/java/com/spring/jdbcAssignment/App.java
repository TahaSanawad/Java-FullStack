package com.spring.jdbcAssignment;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.jdbcAssignment.dao.EmployeeDao;
import com.spring.jdbcAssignment.entities.Employee;

public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext context = new ClassPathXmlApplicationContext("com/spring/jdbcAssignment/config.xml");
		context.getBean("employeeDao", EmployeeDao.class);
		EmployeeDao employeeDao = context.getBean("employeeDao", EmployeeDao.class);
		Employee employee = new Employee();
		//insert
		employee.setId(3); 
		employee.setEmpname("taha");
		employee.setContactno(222);
		employee.setDob("2000-01-02");
		employee.setSalary(40000);
		employee.setEmailid("taha@yash.com");
		int result=employeeDao.insert(employee);
		System.out.println("student added..."+result);
    }
}
