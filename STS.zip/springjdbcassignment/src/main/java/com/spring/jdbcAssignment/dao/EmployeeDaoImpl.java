package com.spring.jdbcAssignment.dao;

import com.spring.jdbcAssignment.entities.Employee;
import org.springframework.jdbc.core.JdbcTemplate;

public class EmployeeDaoImpl implements EmployeeDao{
	private JdbcTemplate jdbcTemplate;
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public int insert(Employee employee) {
		// TODO Auto-generated method stub
		String query="insert into employee values(?,?,?,?,?,?)";
	    int id=employee.getId();
	    int r=this.jdbcTemplate.update(query,id,employee.getEmpname(),employee.getEmailid(),employee.getDob(),employee.getContactno(),employee.getSalary());
	    return r;
	}

	public int change(Employee employee) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int delete(int employeeID) {
		// TODO Auto-generated method stub
		return 0;
	}

}
